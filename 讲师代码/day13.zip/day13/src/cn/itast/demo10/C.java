package cn.itast.demo10;

public class C {
	public void show(){
		new A().abc();
	}
}
