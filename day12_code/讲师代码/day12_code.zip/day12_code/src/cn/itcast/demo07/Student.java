package cn.itcast.demo07;

public class Student extends Person{
	public Student(String name,int age){
		super(name,age);
	}
}
