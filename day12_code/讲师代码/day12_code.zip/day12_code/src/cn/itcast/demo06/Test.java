package cn.itcast.demo06;

public class Test {
	public static void main(String[] args) {
		new Student();
	}
}
