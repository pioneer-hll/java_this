package cn.itast.demo09;

public abstract class Animal {
	public abstract void eat();
	public abstract void sleep();
}
