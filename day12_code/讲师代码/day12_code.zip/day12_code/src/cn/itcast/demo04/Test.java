package cn.itcast.demo04;

public class Test {
	public static void main(String[] args) {
		 Student s = new Student();
		 System.out.println(s.a);
	}
}
