package cn.itast.demo04;

public class Fu {
	static int i = 1;
	
	public static void show(){
		System.out.println("���ྲ̬����show");
	}
}
