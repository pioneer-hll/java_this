package cn.itast.demo01;

public class Test {
	public static void main(String[] args) {
		 Fu f = new Fu();
		 f.show();
	}
}
