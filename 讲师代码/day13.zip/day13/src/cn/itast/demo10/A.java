package cn.itast.demo10;

public class A {
	int i = 1;
	
	protected void abc(){
		System.out.println("ABC");
	}
}
