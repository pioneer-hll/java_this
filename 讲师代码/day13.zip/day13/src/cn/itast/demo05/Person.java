package cn.itast.demo05;

public class Person {
	public void eat(){
		System.out.println("���ڳԷ�");
	}
}
