package cn.itcast.demo04;

public class Person {
	int a = 1;
	public Person(){
		System.out.println("���๹�췽��");
		a=5;
	}
}
