package cn.itcast.demo06;

public class Person extends Object{

	public Person(int a) {
	
	}
	
	
}
